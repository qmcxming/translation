module.exports = {
	'InvalidAccessKeyId.NotFound': '请检查接入码(AccessKeyID)是否正确或者服务是否开通',
	'SignatureDoesNotMatch': '密钥(AccessKeySecret)错误'
};